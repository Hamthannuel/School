class Employee {
    constructor(name, salary, hireDate) {
        this.name = name;
        this.salary = salary;
        this.hireDate = hireDate;

    }
}
    getName() {
        console.log(this.name.toUpperCase());
    }
    getSalary() {
        console.log(this.salary);
    }
    getHireDate() {
        console.log(this.hireDate);
    }

class Manager extends Employee {
    jobDescription() {
        constructor(descriptionOfJob)

        getDescriptionOfJob() {
            console.log(this.jobDescription);
        }

        console.log("Hello, my name is " + this.name + ", my hire date was, " + this.hireDate + ", the hire date is " + this.salary + "the job description is, " + this.jobDescription + ".");
    }
}

class Designer extends Employee {
    yearsExperience(){
        constructor(experience)

        getExperience() {
            console.log(this.experience);
        }
        console.log("Hello, my name is " + this.name + ", my hire date was, " + this.hireDate + ", the hire date is " + this.salary + "and my years of experience are, " + this.descriptionOfJob + ".");
    }
}

class SalesAssociate extends Employee {
    degreeCompleted() {
        constructor(degree)

        getDegree() {
            console.log(this.degree);
        }

        console.log("Hello, my name is " + this.name + ", my hire date was, " + this.hireDate + ", the hire date is " + this.salary + "and my degrees are, " + this.jobDescription + ".");
    }
}